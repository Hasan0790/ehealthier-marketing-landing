const buttons = document.querySelectorAll('.tab-button')
const screens = document.querySelectorAll('.tab-screen')

buttons.forEach((button) => {
  button.addEventListener('click', () => {
    const target = button.dataset.screen

    buttons.forEach((item) => {
      const active = item === button
      item.classList.toggle('active', active)
      item.setAttribute('aria-selected', String(active))
    })

    screens.forEach((screen) => {
      screen.classList.toggle('active', screen.dataset.screenImage === target)
    })
  })
})

const workflowVideo = document.querySelector('#workflow-video video')
const workflowTriggers = document.querySelectorAll('[data-play-workflow]')

workflowTriggers.forEach((trigger) => {
  trigger.addEventListener('click', (event) => {
    event.preventDefault()

    const videoFrame = document.querySelector('#workflow-video')
    videoFrame?.scrollIntoView({ behavior: 'smooth', block: 'center' })

    if (!workflowVideo) return

    const playAttempt = workflowVideo.play()
    videoFrame?.classList.add('playing')

    if (playAttempt) {
      playAttempt.catch(() => {
        videoFrame?.classList.remove('playing')
      })
    }
  })
})

workflowVideo?.addEventListener('play', () => {
  workflowVideo.closest('.hero-visual')?.classList.add('playing')
})

workflowVideo?.addEventListener('pause', () => {
  workflowVideo.closest('.hero-visual')?.classList.remove('playing')
})

document.querySelectorAll('.result-carousel').forEach((carousel) => {
  const slides = Array.from(carousel.querySelectorAll('[data-carousel-slide]'))
  const dots = Array.from(carousel.querySelectorAll('.carousel-dots span'))
  const previous = carousel.querySelector('[data-carousel-prev]')
  const next = carousel.querySelector('[data-carousel-next]')
  let current = 0

  const showSlide = (index) => {
    current = (index + slides.length) % slides.length

    slides.forEach((slide, slideIndex) => {
      slide.classList.toggle('active', slideIndex === current)
    })

    dots.forEach((dot, dotIndex) => {
      dot.classList.toggle('active', dotIndex === current)
    })
  }

  previous?.addEventListener('click', () => showSlide(current - 1))
  next?.addEventListener('click', () => showSlide(current + 1))
})
